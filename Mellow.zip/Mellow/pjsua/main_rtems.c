
/* 
 *  !! OIY OIY !!
 *
 *  The purpose of this file is only to get the executable linked. I haven't
 *  actually tried to run this on RTEMS!!
 *
 */

#include "../../pjlib/src/pjlib-test/main_rtems.c"


