//
//  AppDelegate.h
//  Mellow
//
//  Created by Soumen Rautray on 09/05/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong,nonatomic) UIViewController *viewcontroller;

@end

