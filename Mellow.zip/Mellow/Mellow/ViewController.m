//
//  ViewController.m
//  Mellow
//
//  Created by Soumen Rautray on 09/05/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

#import "ViewController.h"
#import <pjsua.h>
#import <pjlib.h>
#import <pj/log.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
      [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
}

@end
